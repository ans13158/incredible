<!DOCTYPE html>
<!--[if IE 7 ]><html class="ie ie7"><![endif]-->
<!--[if IE 8 ]><html class="ie ie8"><![endif]-->
<!--[if IE 9 ]><html class="ie ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<!-- Mirrored from envato.megadrupal.com/html/bookawesome/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 09 Feb 2017 13:23:13 GMT -->

<head>
    
    <meta charset="utf-8">
    <title>Incredible Uttarakhand</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    
    <!--<link href="http://fonts.googleapis.com/css?family=Lato:300,400%7COpen+Sans:300,400,600" rel="stylesheet" type="text/css">-->
    <?= link_tag('http://fonts.googleapis.com/css?family=Lato:300,400%7COpen+Sans:300,400,600" rel="stylesheet" type="text/css') ?>

    <?= link_tag('css/library/font-awesome.min.css') ?>
    <?= link_tag('css/library/bootstrap.min.css') ?>
    <?= link_tag('css/library/jquery-ui.min.css') ?>
    <?= link_tag('css/library/owl.carousel.css') ?>
    <?= link_tag('css/library/jquery.mb.YTPlayer.min.css') ?>
    <?= link_tag('css/style.css') ?>

    <!--<link rel="stylesheet" href="css/library/font-awesome.min.css">-->
    <!--<link rel="stylesheet" href="css/library/bootstrap.min.css">
    <link rel="stylesheet" href="css/library/jquery-ui.min.css">
    <link rel="stylesheet" href="css/library/owl.carousel.css">
    <link rel="stylesheet" href="css/library/jquery.mb.YTPlayer.min.css">
    <link rel="stylesheet" href="css/style.css">-->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window,
            document, 'script', 'http://connect.facebook.net/en_US/fbevents.js');

        fbq('init', '1031554816897182');
        fbq('track', "PageView");
    </script>
    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1031554816897182&amp;ev=PageView&amp;noscript=1" /></noscript>
</head>