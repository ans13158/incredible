 <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="logo-foter">
                             <a href="" title=""> <?=img( ["src"=>'images/LOGO.png', "height"=>"50", "width"=>'350',"style"=>"margin-left:-60px"]) ?><h5 style="position: absolute;color:white;top:45px;z-index: +99999;margin-left: 60px;font-weight: bold">Tour Planner</h5> </a>
                        </div>
                        <br>

                        <p class="copyright">© Incredible Uttarakhand™ All rights reserved.</p>
                    </div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="ul-ft">
                            <ul>
                                <li><?= anchor('incredible_ukd','Home') ?></li>
                                <li><?= anchor('incredible_ukd/about','About Us') ?></li>
                                <li><?= anchor('incredible_ukd','Location') ?></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="ul-ft">
                            <ul>
                                <li><?= anchor('incredible_ukd','Our Services') ?></li>    
                                <li><?= anchor('incredible_ukd','Destinations') ?></li>
                                <li><?= anchor('incredible_ukd','Tour Packages') ?></li>
                                
                                
                            </ul>

                            <br><br>

                            <p class="about-team"><a href="">Our Team</a> |<a href=""> About Site Developers</a></p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4" style="background-color: #111;height: auto;">
                                <h4 style="color:white;margin-top: 20px;margin-bottom: -70px;margin-left: 20px;">Payment Methods</h4>
                        <div class="currency-lang-bottom dropdown-cn float-left" style="background-color: #111;display:inline-block;width: auto">
                                
                            
                                <?= img(['src'=>'images/cards.png','style'=> "height:50px;width:250px;margin-left:-20px;"]) ?>
                            </div>        
                                    
                                </ul>
                           
                        </div>
                        
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script type="text/javascript" src="<?= base_url('js/library/jquery-1.11.0.min.js') ?>"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript" src="<?= base_url('js/library/jquery-ui.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('js/library/bootstrap.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('js/library/owl.carousel.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('js/library/parallax.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('js/library/jquery.nicescroll.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('js/library/jquery.ui.touch-punch.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('js/library/jquery.mb.YTPlayer.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('js/library/SmoothScroll.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('js/script.js') ?>"></script>



    <!--<script type="text/javascript" src="js/library/jquery-1.11.0.min.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript" src="js/library/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/library/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/library/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/library/parallax.min.js"></script>
    <script type="text/javascript" src="js/library/jquery.nicescroll.js"></script>
    <script type="text/javascript" src="js/library/jquery.ui.touch-punch.min.js"></script>
    <script type="text/javascript" src="js/library/jquery.mb.YTPlayer.min.js"></script>
    <script type="text/javascript" src="js/library/SmoothScroll.js"></script>
    <script type="text/javascript" src="js/script.js"></script>-->
    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', 'http://www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-20585382-5', 'megadrupal.com');
        ga('send', 'pageview');
    </script>
</body>
<!-- Mirrored from envato.megadrupal.com/html/bookawesome/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 09 Feb 2017 13:24:32 GMT -->

</html>